/* Created by Language version: 7.7.0 */
/* NOT VECTORIZED */
#define NRN_VECTORIZED 0
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "scoplib_ansi.h"
#undef PI
#define nil 0
#include "md1redef.h"
#include "section.h"
#include "nrniv_mf.h"
#include "md2redef.h"
 
#if METHOD3
extern int _method3;
#endif

#if !NRNGPU
#undef exp
#define exp hoc_Exp
extern double hoc_Exp(double);
#endif
 
#define nrn_init _nrn_init__PCNMDA
#define _nrn_initial _nrn_initial__PCNMDA
#define nrn_cur _nrn_cur__PCNMDA
#define _nrn_current _nrn_current__PCNMDA
#define nrn_jacob _nrn_jacob__PCNMDA
#define nrn_state _nrn_state__PCNMDA
#define _net_receive _net_receive__PCNMDA 
#define rates rates__PCNMDA 
#define state state__PCNMDA 
 
#define _threadargscomma_ /**/
#define _threadargsprotocomma_ /**/
#define _threadargs_ /**/
#define _threadargsproto_ /**/
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *getarg();
 static double *_p; static Datum *_ppvar;
 
#define t nrn_threads->_t
#define dt nrn_threads->_dt
#define taurise _p[0]
#define taudecay _p[1]
#define gnmdamax _p[2]
#define taurise_0 _p[3]
#define del _p[4]
#define a1 _p[5]
#define taudecay_0 _p[6]
#define a2 _p[7]
#define tauV _p[8]
#define st_gVD _p[9]
#define v0_gVD _p[10]
#define gVI _p[11]
#define Mg _p[12]
#define K0 _p[13]
#define delta _p[14]
#define e _p[15]
#define i _p[16]
#define wf _p[17]
#define g _p[18]
#define A _p[19]
#define B _p[20]
#define C _p[21]
#define gVD _p[22]
#define factor _p[23]
#define tau _p[24]
#define DA _p[25]
#define DB _p[26]
#define DC _p[27]
#define DgVD _p[28]
#define _g _p[29]
#define _tsav _p[30]
#define _nd_area  *_ppvar[0]._pval
 
#if MAC
#if !defined(v)
#define v _mlhv
#endif
#if !defined(h)
#define h _mlhh
#endif
#endif
 
#if defined(__cplusplus)
extern "C" {
#endif
 static int hoc_nrnpointerindex =  -1;
 /* external NEURON variables */
 extern double celsius;
 /* declaration of user functions */
 static double _hoc_Mgblock();
 static double _hoc_rates();
 static int _mechtype;
extern void _nrn_cacheloop_reg(int, int);
extern void hoc_register_prop_size(int, int, int);
extern void hoc_register_limits(int, HocParmLimits*);
extern void hoc_register_units(int, HocParmUnits*);
extern void nrn_promote(Prop*, int, int);
extern Memb_func* memb_func;
 
#define NMODL_TEXT 1
#if NMODL_TEXT
static const char* nmodl_file_text;
static const char* nmodl_filename;
extern void hoc_reg_nmodl_text(int, const char*);
extern void hoc_reg_nmodl_filename(int, const char*);
#endif

 extern Prop* nrn_point_prop_;
 static int _pointtype;
 static void* _hoc_create_pnt(_ho) Object* _ho; { void* create_point_process();
 return create_point_process(_pointtype, _ho);
}
 static void _hoc_destroy_pnt();
 static double _hoc_loc_pnt(_vptr) void* _vptr; {double loc_point_process();
 return loc_point_process(_pointtype, _vptr);
}
 static double _hoc_has_loc(_vptr) void* _vptr; {double has_loc_point();
 return has_loc_point(_vptr);
}
 static double _hoc_get_loc_pnt(_vptr)void* _vptr; {
 double get_loc_point_process(); return (get_loc_point_process(_vptr));
}
 extern void _nrn_setdata_reg(int, void(*)(Prop*));
 static void _setdata(Prop* _prop) {
 _p = _prop->param; _ppvar = _prop->dparam;
 }
 static void _hoc_setdata(void* _vptr) { Prop* _prop;
 _prop = ((Point_process*)_vptr)->_prop;
   _setdata(_prop);
 }
 /* connect user functions to hoc names */
 static VoidFunc hoc_intfunc[] = {
 0,0
};
 static Member_func _member_func[] = {
 "loc", _hoc_loc_pnt,
 "has_loc", _hoc_has_loc,
 "get_loc", _hoc_get_loc_pnt,
 "Mgblock", _hoc_Mgblock,
 "rates", _hoc_rates,
 0, 0
};
#define Mgblock Mgblock_PCNMDA
 extern double Mgblock( double );
 /* declare global and static user variables */
#define Q10 Q10_PCNMDA
 double Q10 = 1.52;
#define T0 T0_PCNMDA
 double T0 = 26;
#define b2 b2_PCNMDA
 double b2 = 0.0239;
#define b1 b1_PCNMDA
 double b1 = 0.0324;
#define gnmdamax gnmdamax_PCNMDA
 double gnmdamax = 0.96;
#define inf inf_PCNMDA
 double inf = 0;
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 "tauV", 1e-09, 1e+09,
 0,0,0
};
 static HocParmUnits _hoc_parm_units[] = {
 "gnmdamax_PCNMDA", "ns",
 "b1_PCNMDA", "1/mV",
 "b2_PCNMDA", "1/mV",
 "T0_PCNMDA", "degC",
 "inf_PCNMDA", "uS",
 "taurise", "ms",
 "taudecay", "ms",
 "gnmdamax", "ns",
 "taurise_0", "ms",
 "del", "ms",
 "a1", "ms",
 "taudecay_0", "ms",
 "a2", "ms",
 "tauV", "ms",
 "st_gVD", "1/mV",
 "v0_gVD", "mV",
 "gVI", "uS",
 "Mg", "mM",
 "K0", "mM",
 "delta", "1",
 "e", "mV",
 "A", "ns",
 "B", "ns",
 "gVD", "uS",
 "i", "nA",
 "g", "us",
 0,0
};
 static double A0 = 0;
 static double B0 = 0;
 static double C0 = 0;
 static double delta_t = 0.01;
 static double gVD0 = 0;
 static double v = 0;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 "gnmdamax_PCNMDA", &gnmdamax_PCNMDA,
 "b1_PCNMDA", &b1_PCNMDA,
 "b2_PCNMDA", &b2_PCNMDA,
 "Q10_PCNMDA", &Q10_PCNMDA,
 "T0_PCNMDA", &T0_PCNMDA,
 "inf_PCNMDA", &inf_PCNMDA,
 0,0
};
 static DoubVec hoc_vdoub[] = {
 0,0,0
};
 static double _sav_indep;
 static void nrn_alloc(Prop*);
static void  nrn_init(_NrnThread*, _Memb_list*, int);
static void nrn_state(_NrnThread*, _Memb_list*, int);
 static void nrn_cur(_NrnThread*, _Memb_list*, int);
static void  nrn_jacob(_NrnThread*, _Memb_list*, int);
 static void _hoc_destroy_pnt(_vptr) void* _vptr; {
   destroy_point_process(_vptr);
}
 
static int _ode_count(int);
static void _ode_map(int, double**, double**, double*, Datum*, double*, int);
static void _ode_spec(_NrnThread*, _Memb_list*, int);
static void _ode_matsol(_NrnThread*, _Memb_list*, int);
 
#define _cvode_ieq _ppvar[2]._i
 static void _ode_matsol_instance1(_threadargsproto_);
 /* connect range variables in _p that hoc is supposed to know about */
 static const char *_mechanism[] = {
 "7.7.0",
"PCNMDA",
 "taurise",
 "taudecay",
 "gnmdamax",
 "taurise_0",
 "del",
 "a1",
 "taudecay_0",
 "a2",
 "tauV",
 "st_gVD",
 "v0_gVD",
 "gVI",
 "Mg",
 "K0",
 "delta",
 "e",
 0,
 "i",
 "wf",
 "g",
 0,
 "A",
 "B",
 "C",
 "gVD",
 0,
 0};
 
extern Prop* need_memb(Symbol*);

static void nrn_alloc(Prop* _prop) {
	Prop *prop_ion;
	double *_p; Datum *_ppvar;
  if (nrn_point_prop_) {
	_prop->_alloc_seq = nrn_point_prop_->_alloc_seq;
	_p = nrn_point_prop_->param;
	_ppvar = nrn_point_prop_->dparam;
 }else{
 	_p = nrn_prop_data_alloc(_mechtype, 31, _prop);
 	/*initialize range parameters*/
 	taurise = 8;
 	taudecay = 30;
 	gnmdamax = 0.96;
 	taurise_0 = 2.234;
 	del = 0;
 	a1 = 0.0896;
 	taudecay_0 = 62.5808;
 	a2 = 10.0374;
 	tauV = 7;
 	st_gVD = 0.007;
 	v0_gVD = -100;
 	gVI = 1;
 	Mg = 1;
 	K0 = 4.1;
 	delta = 0.8;
 	e = -0.7;
  }
 	_prop->param = _p;
 	_prop->param_size = 31;
  if (!nrn_point_prop_) {
 	_ppvar = nrn_prop_datum_alloc(_mechtype, 3, _prop);
  }
 	_prop->dparam = _ppvar;
 	/*connect ionic variables to this model*/
 
}
 static void _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 0,0
};
 static void _net_receive(Point_process*, double*, double);
 extern Symbol* hoc_lookup(const char*);
extern void _nrn_thread_reg(int, int, void(*)(Datum*));
extern void _nrn_thread_table_reg(int, void(*)(double*, Datum*, Datum*, _NrnThread*, int));
extern void hoc_register_tolerance(int, HocStateTolerance*, Symbol***);
extern void _cvode_abstol( Symbol**, double*, int);

 void _PCNMDA_reg() {
	int _vectorized = 0;
  _initlists();
 	_pointtype = point_register_mech(_mechanism,
	 nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init,
	 hoc_nrnpointerindex, 0,
	 _hoc_create_pnt, _hoc_destroy_pnt, _member_func);
 _mechtype = nrn_get_mechtype(_mechanism[1]);
     _nrn_setdata_reg(_mechtype, _setdata);
 #if NMODL_TEXT
  hoc_reg_nmodl_text(_mechtype, nmodl_file_text);
  hoc_reg_nmodl_filename(_mechtype, nmodl_filename);
#endif
  hoc_register_prop_size(_mechtype, 31, 3);
  hoc_register_dparam_semantics(_mechtype, 0, "area");
  hoc_register_dparam_semantics(_mechtype, 1, "pntproc");
  hoc_register_dparam_semantics(_mechtype, 2, "cvodeieq");
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 pnt_receive[_mechtype] = _net_receive;
 pnt_receive_size[_mechtype] = 1;
 	hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 PCNMDA G:/Peking/my work/NMDA/NMDA-PC-2/NMPA-2/Fig7/SS+CS+disa+Ca/PF_500_CF_500_dend/PCNMDA.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
 static double T = 273.16;
 static double F = 9.648e4;
 static double R = 8.315;
 static double z = 2;
static int _reset;
static char *modelname = "";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static void _modl_cleanup(){ _match_recurse=1;}
static int rates(double);
 
static int _ode_spec1(_threadargsproto_);
/*static int _ode_matsol1(_threadargsproto_);*/
 static double *_temp1;
 static int _slist1[3], _dlist1[3];
 static int state(_threadargsproto_);
 
/*CVODE*/
 static int _ode_spec1 () {_reset=0;
 {
   rates ( _threadargscomma_ v ) ;
   DA = - A / taurise ;
   DB = - B / taudecay ;
   DgVD = ( B / wf ) * ( inf - gVD ) / tau ;
   }
 return _reset;
}
 static int _ode_matsol1 () {
 rates ( _threadargscomma_ v ) ;
 DA = DA  / (1. - dt*( ( - 1.0 ) / taurise )) ;
 DB = DB  / (1. - dt*( ( - 1.0 ) / taudecay )) ;
 DgVD = DgVD  / (1. - dt*( ( ( ( B / wf ) )*( ( ( - 1.0 ) ) ) ) / tau )) ;
  return 0;
}
 /*END CVODE*/
 
static int state () {_reset=0;
 {
   rates ( _threadargscomma_ v ) ;
   DA = - A / taurise ;
   DB = - B / taudecay ;
   DgVD = ( B / wf ) * ( inf - gVD ) / tau ;
   }
 return _reset;}
 
static void _net_receive (_pnt, _args, _lflag) Point_process* _pnt; double* _args; double _lflag; 
{    _p = _pnt->_prop->param; _ppvar = _pnt->_prop->dparam;
  if (_tsav > t){ extern char* hoc_object_name(); hoc_execerror(hoc_object_name(_pnt->ob), ":Event arrived out of order. Must call ParallelContext.set_maxstep AFTER assigning minimum NetCon.delay");}
 _tsav = t; {
   if ( t > del ) {
     wf = _args[0] * factor * gnmdamax ;
       if (nrn_netrec_state_adjust && !cvode_active_){
    /* discon state adjustment for general derivimplicit and KINETIC case */
    int __i, __neq = 3;
    double __state = A;
    double __primary_delta = (A + wf) - __state;
    double __dtsav = dt;
    for (__i = 0; __i < __neq; ++__i) {
      _p[_dlist1[__i]] = 0.0;
    }
    _p[_dlist1[0]] = __primary_delta;
    dt *= 0.5;
    v = NODEV(_pnt->node);
    _ode_matsol_instance1(_threadargs_);
    dt = __dtsav;
    for (__i = 0; __i < __neq; ++__i) {
      _p[_slist1[__i]] += _p[_dlist1[__i]];
    }
  } else {
 A = A + wf ;
       }
   if (nrn_netrec_state_adjust && !cvode_active_){
    /* discon state adjustment for general derivimplicit and KINETIC case */
    int __i, __neq = 3;
    double __state = B;
    double __primary_delta = (B + wf) - __state;
    double __dtsav = dt;
    for (__i = 0; __i < __neq; ++__i) {
      _p[_dlist1[__i]] = 0.0;
    }
    _p[_dlist1[1]] = __primary_delta;
    dt *= 0.5;
    v = NODEV(_pnt->node);
    _ode_matsol_instance1(_threadargs_);
    dt = __dtsav;
    for (__i = 0; __i < __neq; ++__i) {
      _p[_slist1[__i]] += _p[_dlist1[__i]];
    }
  } else {
 B = B + wf ;
       }
 }
   } }
 
double Mgblock (  double _lv ) {
   double _lMgblock;
 _lMgblock = 1.0 / ( 1.0 + ( Mg / K0 ) * exp ( ( 0.001 ) * ( - z ) * delta * F * _lv / R / ( T + celsius ) ) ) ;
   
return _lMgblock;
 }
 
static double _hoc_Mgblock(void* _vptr) {
 double _r;
    _hoc_setdata(_vptr);
 _r =  Mgblock (  *getarg(1) );
 return(_r);
}
 
static int  rates (  double _lv ) {
   inf = ( _lv - v0_gVD ) * st_gVD * gVI ;
    return 0; }
 
static double _hoc_rates(void* _vptr) {
 double _r;
    _hoc_setdata(_vptr);
 _r = 1.;
 rates (  *getarg(1) );
 return(_r);
}
 
static int _ode_count(int _type){ return 3;}
 
static void _ode_spec(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
     _ode_spec1 ();
 }}
 
static void _ode_map(int _ieq, double** _pv, double** _pvdot, double* _pp, Datum* _ppd, double* _atol, int _type) { 
 	int _i; _p = _pp; _ppvar = _ppd;
	_cvode_ieq = _ieq;
	for (_i=0; _i < 3; ++_i) {
		_pv[_i] = _pp + _slist1[_i];  _pvdot[_i] = _pp + _dlist1[_i];
		_cvode_abstol(_atollist, _atol, _i);
	}
 }
 
static void _ode_matsol_instance1(_threadargsproto_) {
 _ode_matsol1 ();
 }
 
static void _ode_matsol(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
 _ode_matsol_instance1(_threadargs_);
 }}

static void initmodel() {
  int _i; double _save;_ninits++;
 _save = t;
 t = 0.0;
{
  A = A0;
  B = B0;
  C = C0;
  gVD = gVD0;
 {
   double _ltp ;
 rates ( _threadargscomma_ v ) ;
   if ( taurise / taudecay > .9999 ) {
     taurise = .9999 * taudecay ;
     }
   A = 0.0 ;
   B = 0.0 ;
   _ltp = ( taurise * taudecay ) / ( taudecay - taurise ) * log ( taudecay / taurise ) ;
   factor = - exp ( - _ltp / taurise ) + exp ( - _ltp / taudecay ) ;
   factor = 1.0 / factor ;
   tau = tauV * pow( Q10 , ( ( T0 - celsius ) / 10.0 ) ) ;
   gVD = 0.0 ;
   wf = 1.0 ;
   Mgblock ( _threadargscomma_ v ) ;
   }
  _sav_indep = t; t = _save;

}
}

static void nrn_init(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
 _tsav = -1e20;
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 v = _v;
 initmodel();
}}

static double _nrn_current(double _v){double _current=0.;v=_v;{ {
   g = ( B - A ) * ( gVI + gVD ) * Mgblock ( _threadargscomma_ v ) ;
   i = ( B - A ) * ( gVI + gVD ) * Mgblock ( _threadargscomma_ v ) * ( v - e ) ;
   }
 _current += i;

} return _current;
}

static void nrn_cur(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 _g = _nrn_current(_v + .001);
 	{ _rhs = _nrn_current(_v);
 	}
 _g = (_g - _rhs)/.001;
 _g *=  1.e2/(_nd_area);
 _rhs *= 1.e2/(_nd_area);
#if CACHEVEC
  if (use_cachevec) {
	VEC_RHS(_ni[_iml]) -= _rhs;
  }else
#endif
  {
	NODERHS(_nd) -= _rhs;
  }
 
}}

static void nrn_jacob(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml];
#if CACHEVEC
  if (use_cachevec) {
	VEC_D(_ni[_iml]) += _g;
  }else
#endif
  {
     _nd = _ml->_nodelist[_iml];
	NODED(_nd) += _g;
  }
 
}}

static void nrn_state(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; double _v = 0.0; int* _ni; int _iml, _cntml;
double _dtsav = dt;
if (secondorder) { dt *= 0.5; }
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
 _nd = _ml->_nodelist[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 v=_v;
{
 { error =  runge(_ninits, 3, _slist1, _dlist1, _p, &t, dt, state, &_temp1);
 if(error){fprintf(stderr,"at line 110 in file PCNMDA.mod:\n	SOLVE state METHOD runge : cnexp\n"); nrn_complain(_p); abort_run(error);}
    if (secondorder) {
    int _i;
    for (_i = 0; _i < 3; ++_i) {
      _p[_slist1[_i]] += dt*_p[_dlist1[_i]];
    }}
  state();
 }}}
 dt = _dtsav;
}

static void terminal(){}

static void _initlists() {
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = &(A) - _p;  _dlist1[0] = &(DA) - _p;
 _slist1[1] = &(B) - _p;  _dlist1[1] = &(DB) - _p;
 _slist1[2] = &(gVD) - _p;  _dlist1[2] = &(DgVD) - _p;
_first = 0;
}

#if NMODL_TEXT
static const char* nmodl_filename = "PCNMDA.mod";
static const char* nmodl_file_text = 
  "\n"
  "\n"
  "NEURON {\n"
  "	POINT_PROCESS PCNMDA\n"
  "	NONSPECIFIC_CURRENT i\n"
  "	RANGE  taurise_0, a1, taudecay_0, a2, tauV, e, i, gVI, st_gVD, v0_gVD, Mg, K0, delta, wf,g\n"
  "	RANGE taurise, taudecay,del,gnmdamax\n"
  "	GLOBAL inf,gnmdamax\n"
  "	THREADSAFE\n"
  "}\n"
  "\n"
  "UNITS {\n"
  "	(nA) = (nanoamp)\n"
  "	(mV) = (millivolt)\n"
  "	(uS) = (microsiemens)\n"
  "	(nS) 	= (nanomho)\n"
  "	(mM) = (milli/liter)\n"
  "	(S)  = (siemens)\n"
  "	(pS) = (picosiemens)\n"
  "	(um) = (micron)\n"
  "	(J)  = (joules)\n"
  "}\n"
  "\n"
  "PARAMETER {\n"
  ": Parameters Control Neurotransmitter and Voltage-dependent gating of NMDAR\n"
  "	: parameters control exponential decay of taurise\n"
  "	taurise=8 (ms)\n"
  "	taudecay=30 (ms)\n"
  "	gnmdamax=0.96  (ns)\n"
  "	taurise_0 = 2.2340 (ms)\n"
  "	del=0 (ms)\n"
  "	a1 = 0.0896		(ms)\n"
  "	b1 = 0.0324		(1/mV)\n"
  "	\n"
  "	: parameters control exponential rise to a maximum\n"
  "	taudecay_0 = 62.5808 (ms)\n"
  "	a2 = 10.0374	 (ms)\n"
  "	b2 = 0.0239		 (1/mV)\n"
  "\n"
  ": Parameters Control voltage-dependent gating of NMDAR\n"
  "	tauV = 7		(ms)	<1e-9,1e9>	: Kim11 \n"
  "							: at 26 degC & [Mg]o = 1 mM, \n"
  "							: [Mg]o = 0 reduces value of this parameter\n"
  "							: Because TauV at room temperature (20) & [Mg]o = 1 mM is 9.12 Clarke08 & Kim11 \n"
  "							: and because Q10 at 26 degC is 1.52\n"
  "							: then tauV at 26 degC should be 7 \n"
  "	st_gVD = 0.007	(1/mV)	: steepness of the gVD-V graph from Clarke08 -> 2 units / 285 mv\n"
  "	v0_gVD = -100	(mV)	: Membrane potential at which there is no voltage dependent current, from Clarke08 -> -90 or -100\n"
  "	gVI = 1			(uS)	: Maximum Conductance of Voltage Independent component, This value is used to calculate gVD\n"
  "	Q10 = 1.52				: Kim11\n"
  "	T0 = 26			(degC)	: reference temperature \n"
  "	celsius 		(degC)	: actual temperature for simulation, defined in Neuron, usually about 35\n"
  ": Parameters Control Mg block of NMDAR\n"
  "	Mg = 1			(mM)	: external magnesium concentration from Spruston95\n"
  "	K0 = 4.1		(mM)	: IC50 at 0 mV from Spruston95\n"
  "	delta = 0.8 	(1)		: the electrical distance of the Mg2+ binding site from the outside of the membrane from Spruston95\n"
  ": Parameter Controls Ohm's law in NMDAR\n"
  "	e = -0.7		(mV)	: in CA1-CA3 region = -0.7 from Spruston95\n"
  "}\n"
  "\n"
  "CONSTANT {\n"
  "	T = 273.16	(degC)\n"
  "	F = 9.648e4	(coul)	: Faraday's constant (coulombs/mol)\n"
  "	R = 8.315	(J/degC): universal gas constant (joules/mol/K)\n"
  "	z = 2		(1)		: valency of Mg2+\n"
  "}\n"
  "\n"
  "ASSIGNED {\n"
  "	v		(mV)\n"
  "	dt		(ms)\n"
  "	i		(nA)\n"
  "	factor\n"
  "	wf\n"
  "	g       (us)\n"
  "	inf		(uS)\n"
  "	tau		(ms)\n"
  "	\n"
  "}\n"
  "\n"
  "STATE {\n"
  "	A (ns)\n"
  "	B (ns)\n"
  "	C\n"
  "	gVD (uS)\n"
  "	\n"
  "	}\n"
  "\n"
  "INITIAL {\n"
  "	LOCAL tp\n"
  "	rates(v)\n"
  "	if (taurise/taudecay > .9999) {\n"
  "		taurise = .9999*taudecay\n"
  "	}\n"
  "	A = 0\n"
  "	B = 0\n"
  "	tp = (taurise*taudecay)/(taudecay - taurise) * log(taudecay/taurise)\n"
  "	factor = -exp(-tp/taurise) + exp(-tp/taudecay)\n"
  "	factor = 1/factor\n"
  "	\n"
  "	: temperature-sensitivity of the slow unblock of NMDARs\n"
  "	tau = tauV * Q10^((T0 - celsius)/10(degC))\n"
  "\n"
  "	gVD = 0\n"
  "	wf = 1\n"
  "	Mgblock(v)\n"
  "	\n"
  "}\n"
  "\n"
  "BREAKPOINT {\n"
  "	SOLVE state METHOD runge : cnexp\n"
  "	g=(B - A)*(gVI + gVD)*Mgblock(v)\n"
  "	i = (B - A)*(gVI + gVD)*Mgblock(v)*(v - e)	\n"
  "	:printf(\"%gss\\n\",i)\n"
  "}\n"
  "\n"
  "DERIVATIVE state {\n"
  "	rates(v)\n"
  "	A' = -A/taurise\n"
  "	B' = -B/taudecay\n"
  "	: Voltage Dapaendent Gating of NMDA needs prior binding to Glutamate Kim11\n"
  "	gVD' = (B/wf)*(inf-gVD)/tau		\n"
  "}\n"
  "\n"
  "NET_RECEIVE(weight(nanomho)) {\n"
  "	if(t>del){\n"
  "		wf = weight*factor*gnmdamax\n"
  "		A = A + wf 	\n"
  "		B = B + wf\n"
  "	}	\n"
  "}\n"
  "\n"
  "FUNCTION Mgblock(v(mV)) {\n"
  "	: from Spruston95\n"
  "	Mgblock = 1 / (1 + (Mg/K0)*exp((0.001)*(-z)*delta*F*v/R/(T+celsius)))\n"
  "}\n"
  "\n"
  "PROCEDURE rates(v (mV)) { \n"
  "		\n"
  "	inf = (v - v0_gVD) * st_gVD * gVI\n"
  "	\n"
  "}\n"
  ;
#endif
