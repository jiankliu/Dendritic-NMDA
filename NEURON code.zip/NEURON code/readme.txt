
Compile the mod files and run main.hoc for the main simulation
